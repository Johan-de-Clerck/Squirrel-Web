SQUIRREL STUDIO WEB 0.1.28

Open index.html in Chrome or Edge. Click START AUDIO.

In MIDI / AUDIO > Save & load project, enter an optional PROJECT NAME.
If set, the filename is PROJECT NAME.json (invalid filename characters are sanitized).
If blank, a default SquirrelStudio_0.1.28_YYYY-MM-DD_HH-mm-ss.json filename is used.
Project names are saved in project JSON and restored when you load a project.

This complete web version includes beige Follow, per-track steps 1-32, longest-track Song Mode pattern changes, custom pattern names, and HOME/END/DEL.
