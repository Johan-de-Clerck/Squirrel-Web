SQUIRREL STUDIO WEB 0.1.28

Open index.html in a modern browser, then click START AUDIO.

PROJECT NAME: Enter a name under MIDI / AUDIO > Save & load project. Save produces "Your Name.json". When blank, a default filename with the local date and time is used.
Project names are stored inside the JSON and restored when the project is loaded.

Also included:
- Beige Follow marker
- Adjustable per-track step lengths (1 to 32, default 32)
- Song Mode waits for the longest track; shorter tracks loop
- Named patterns and Song Mode arrangement
- HOME / END and DEL keyboard shortcuts
- Reduced in-app help copy

This is the full web editor, not a native Windows executable.
