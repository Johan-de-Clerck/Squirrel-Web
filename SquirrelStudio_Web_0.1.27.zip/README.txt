Squirrel Studio Web 0.1.27

Open index.html in a modern browser (Chrome/Edge recommended).
Click START AUDIO to initialize the synth.

Changes:
- Beige playback position indicator
- Per-pattern, per-track step lengths (1-32, default 32)
- Short tracks repeat until the longest track finishes; Song Mode changes at that boundary
- Rename patterns (e.g. A1 to Intro), preserved in project JSON
- HOME/END navigation, DEL removes the selected note
- English interface, explanatory help text removed
