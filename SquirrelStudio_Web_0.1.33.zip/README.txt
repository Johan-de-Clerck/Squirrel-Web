SQUIRREL STUDIO WEB 0.1.33

Run on Chrome or Edge. Upload index.html and demo.json in the same directory
on your website (HTTPS recommended). Click AUDIO ON to start audio.

SAMPLE BANK (.json)
- Open DRUM SAMPLES > EXPORT BANK or OPTIONS > EXPORT SAMPLE BANK.
- Save one *_Samples.json file containing the actual audio (embedded as base64).
- On another PC/browser open IMPORT BANK and select your saved file.
- The bank contains 5 sample slots for each of drum tracks 1, 2, 3,
  plus the two audio sampler tracks 7 and 8 (17 sample positions total).
- Import REPLACES these sample slots after confirmation.
- Import does NOT change your patterns, step/sample-slot assignments or Song Mode.
- Samples and sampler markers / tuning for tracks 7/8 are included.
- For a complete song backup, continue using SAVE PROJECT (.JSON).

DEMO
- demo.json is an exported project file in the same folder as index.html.
- With no local project, it loads on first visit.
- OPTIONS > LOAD DEMO.JSON loads it on demand.
- OPTIONS > AUTO-LOAD ON START opts in to loading it every startup.

KEYBOARD
- Click selects a step without changing its note.
- ENTER toggles note. DELETE removes note.
- HOME jumps to first step; END to last active step.
- Each track can be 1-32 steps. Shorter tracks loop.

This is a web editor, not a Windows executable.
