SQUIRREL STUDIO WEB 0.1.32

Upload index.html and demo.json to the SAME directory (typically the website root).
Open the website via HTTPS (or localhost), then click START AUDIO to hear playback.

DEMO SONG
- demo.json automatically loads for a new visitor who has no locally saved project.
- Existing locally saved projects take priority.
- OPTIONS > LOAD DEMO.JSON loads the file from the site on demand, after confirmation.
- OPTIONS > AUTO-LOAD ON START makes demo.json load on every launch (replaces the local saved song).
- You may replace demo.json with any project exported via SAVE PROJECT, renamed to demo.json.
- When the file is absent, the built-in demo remains available; the webapp still starts.

DRUM SAMPLES (TRACKS 1-3)
- DRUM SAMPLES has five sample slots per drum track (15 slots total).
- Load samples, select a step, and choose a sample slot in STEP EDITOR.
- Click a grid step to select it; ENTER toggles note, DELETE clears note.
- Shorter tracks repeat until the longest track finishes during Song Mode.
- Existing drum synthesis plays on a drum track until sample slots are loaded there.

This is a standalone browser project, not a Windows executable.
