SQUIRREL STUDIO WEB 0.1.30

Open index.html in Chrome or Edge. Click START AUDIO before playing.

Sequencer editor:
- Click a note or FX step to select it without changing its note or FX.
- Press ENTER on the selected sequencer cell to toggle its note ON/OFF.
- Press DELETE to clear the selected step's note (FX is preserved).
- Turn EDIT ON to type notes with the computer keyboard.
- HOME goes to the first step, END to the last step of that track.

Other features (pattern names, per-track step counts, Song Mode, project JSON name) are retained.
