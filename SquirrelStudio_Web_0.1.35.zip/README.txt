SQUIRREL STUDIO WEB 0.1.35

Upload index.html and demo.json together to your website root and open using HTTPS.
Click AUDIO ON to activate the synthesizer.

NEW: Remember the active drum sample slot
Each of drum tracks 1, 2 and 3 independently remembers the latest slot you chose (1–5).
- In DRUM SAMPLES press USE for a slot. The selected slot is highlighted ACTIVE.
- Loading an audio sample automatically selects its slot.
- In STEP EDITOR, choosing SAMPLE remembers it for the current drum track.
- On an EMPTY step the SAMPLE dropdown shows the remembered slot.
- Press ENTER or type a keyboard note in EDIT mode: that remembered slot is used.
- Existing active steps retain their saved slot; selecting one displays its own sound.
- Project JSON preserves the three remembered slot values. Old projects still load.

Step editing from version 0.1.34:
- Mouse clicks only select steps; ENTER toggles and DELETE clears.
- Ctrl+C / Ctrl+V on a focused grid step copies/pastes all step fields.
- COPY STEP and PASTE STEP buttons are in Step Editor.
- Save Project waits for sample restoration before exporting the song.

The sample bank feature exports/imports drum tracks 1-3 and samplers 7-8.
OPTIONS > LOAD DEMO.JSON loads the website's demo song.
